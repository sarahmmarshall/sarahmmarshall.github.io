from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # Connection Variables
        connection_string = "mongodb+srv://Cluster03782:AZGIig00T7FKjOgA@cluster03782.sdazc.mongodb.net/"
        # Initialize Connection
        self.client = MongoClient(connection_string)
        self.database = self.client['AAC']
        self.collection = self.database['animals']           

# Create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            result = self.database.animals.insert_one(data)  # data should be dictionary  
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

# Read method to implement the R in CRUD.
    def read(self, query):
        results = list(self.collection.find(query)) # data should be dictionary
        if results:
            return results
        else:
            return [] # returns list

# Update method to implement the U in CRUD.
    def update(self, query, update_data):
        results = self.collection.update_many(query, {"$set": update_data}) #finds data to be updated
        if results.modified_count > 0:
            return results.modified_count # the specified data that is found is updated
        else: # else specified data was not found
            raise Exception("No data was updated")
        
# Delete method to implement the D in CRUD.
    def delete(self, query):
        results = self.collection.delete_many(query) #finds data to be deleted
        if results.deleted_count > 0:
            return results.deleted_count # the specified data that is found is deleted
        else: # else specified data was not found
            raise Exception("No data was deleted")
        
        