var searchData=
[
  ['release_20notes_0',['Release notes',['../news.html',1,'']]]
];
