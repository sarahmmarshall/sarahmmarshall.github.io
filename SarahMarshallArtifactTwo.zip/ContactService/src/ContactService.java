import java.util.HashMap;

public class ContactService {
	HashMap<String, Contact> contacts = new HashMap<>(); // store contacts using HashMap


	public void addContact(Contact c) { // method for adding contact
		if(!contacts.containsKey(c.getid())) { //searches for key (id)
       contacts.put(c.getid(), c); //adds key (id) to HashMap with value
      }
	}

	public void delete(String id) { // method for deleting contact
		if(contacts.containsKey(id)) { //searches for key (id)
			contacts.remove(id); // deletes contact with that id in the HashMap
			}
		System.out.println("id does not exists"); // prints this if the id does not exist
	}

	public Contact getContactById(String id) { // method to fetch id of contacts to be used in ContactServiceTest.java
    	return contacts.get(id); //returns id with its value that it searched for
				}
 
	public void updateContact(String id, String firstName, String lastName, String phoneNumber, String address) { // method to update contact based off id
		Contact updateContact = contacts.get(id); //attempts to get id from the HashMap
		if (contacts.containsKey(id)) { // if id exists in the HashMap
		    updateContact.setfirstName(firstName); //updates first name
		    updateContact.setlastName(lastName); //updates last name
		    updateContact.setphoneNumber(phoneNumber); //updates phone number
		    updateContact.setaddress(address); //updates address
				}	
			}
		}
	