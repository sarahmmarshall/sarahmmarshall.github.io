
import org.junit.Test;

import static org.junit.Assert.*;

public class ContactServiceTest {
	@Test
	public void testContactServiceAdd() { //method to test add contact by id
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH"); //example for a contact with all attributes
		ContactService contactservice = new ContactService(); // creates an object of class ContactService.java
		contactservice.addContact(contact); // calling addContact method from ContactService.java
		assertEquals(contactservice.contacts.size(), 1); //compares new contact to 1
	}

	@Test
	public void testContactServiceDelete() { //method to test delete contact by id
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH"); //same contact example for deleting the previous contact
		ContactService contactservice = new ContactService(); //creates an object ContactService.java
		contactservice.addContact(contact); //calling addContact method from ContactService.java
		contactservice.delete(contact.getid()); //calling deleteContact method from ContactService.java
		assertEquals(contactservice.contacts.size(), 0); //compares new contact to 0
	}

	@Test
	public void testContactServiceUpdate() { //method to test update contact by id
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH"); //same contact example for adding & deleting the previous contact
		ContactService contactservice = new ContactService();// creates an object of a class
		contactservice.addContact(contact); // adds contact to the contact service
		Contact updatedContact = new Contact("1224", "Jole", "Bake", "6031112223", "1 Lay Road Dover NH"); //updated contact example to test whether it works
		contactservice.updateContact("1224", "Jole", "Bake", "6031112223", "1 Lay Road Dover NH"); //calling update contact method
		Contact retrievedContact = contactservice.getContactById("1224"); //retrieves contacts by id 1224

		assertEquals(retrievedContact.getfirstName(), updatedContact.getfirstName()); //updated first name to test if it works
		assertEquals(retrievedContact.getlastName(), updatedContact.getlastName());//updated last name to test if it works
		assertEquals(retrievedContact.getphoneNumber(),updatedContact.getphoneNumber()); //updated phone number to test if it works
		assertEquals(retrievedContact.getaddress(),updatedContact.getaddress()); //updated address to test if it works
		
	}
}