import java.util.ArrayList;

public class ContactService {
	ArrayList<Contact> contacts = new ArrayList<Contact>(); // creates lost to store contacts

	public void addContact(Contact c) { // method for adding contact
		for (Contact list : contacts) {// for loop
			if (list.getid() == c.getid()) // checks if another contact has same id
				return; // as c's and returns if it matches
		}
		contacts.add(c); // adds new contact if the id is not already existing
	}

	public void delete(String id) { // method for deleting contact
		for (Contact c : contacts) { // for loop
			if (c.getid().equals(id)) { // checks if id exists
				contacts.remove(c); // deletes contact with that id
				// System.out.println("Contact with that ID is deleted");
				return;
			}
		}
		System.out.println("id does not exists"); // prints this if the id they are
	}// searching for does not exist

	public Contact getContactById(String id) { // method to fetch get id of contacts to be used in ContactServiceTest
		for (Contact list : contacts) {// for loop
			if (list.getid().equals(id)) { // checks if id exists
				return list;
			}
		}
		return null;
	}

	public void updateContact(Contact updatedContact) { // method to update all contacts based off id
		for (Contact list : contacts) {
			if (list.getid().equals(updatedContact.getid())) { // fetches id to update that specific id
				list.setfirstName(updatedContact.getfirstName()); // updates first name
				list.setlastName(updatedContact.getlastName()); // updates last name
				list.setphoneNumber(updatedContact.getphoneNumber()); // updates phone number
				list.setaddress(updatedContact.getaddress()); // updates address
				return;
			}

		}
	}
}
