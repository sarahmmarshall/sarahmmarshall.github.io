
import org.junit.Test;

import static org.junit.Assert.*;

public class ContactTest {

	@Test
	public void testContactCreationIDLong() { //test for id > 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setid("12241111111111");
		assertEquals("1224", contact.getid()); // asserts that two objects are equal, the id length
	}

	@Test
	public void testContactCreationIDTen() { //tests for id = 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setid("1234567890");
		assertEquals("1234567890", contact.getid()); // asserts that two objects are equal, the id length
	}

	@Test
	public void testContactCreationIDLessTen() { //tests for id < 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setid("12245");
		assertEquals("12245", contact.getid()); // asserts that two objects are equal, the id length
	}

	@Test
	public void testContactCreationFirstNameLong() { //tests for first name > 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setfirstName("Jackkkkkkkkkkkkkk");
		assertEquals("John", contact.getfirstName()); // asserts that two objects are equal, the first name length
	}

	@Test
	public void testContactCreationFirstNameTen() { //tests for first name = 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setfirstName("Joshhhhhhh");
		assertEquals("Joshhhhhhh", contact.getfirstName()); // asserts that two objects are equal, the first name length
	}

	@Test
	public void testContactCreationFirstNameLessTen() { //tests for first name < 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setfirstName("Ben");
		assertEquals("Ben", contact.getfirstName()); // asserts that two objects are equal, the first name length
	}

	@Test
	public void testContactCreationLastNameLong() { //tests for last name > 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setlastName("Konellllllllll");
		assertEquals("Donell", contact.getlastName()); // asserts that two objects are equal, the last name length
	}

	@Test
	public void testContactCreationLastNameTen() {  //tests for last name = 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setlastName("Konellllll");
		assertEquals("Konellllll", contact.getlastName()); // asserts that two objects are equal, the last name length
	}

	@Test
	public void testContactCreationLastNameLessTen() { //tests for last name < 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setlastName("Konel");
		assertEquals("Konel", contact.getlastName()); // asserts that two objects are equal, the last name length
	}

	@Test
	public void testContactCreationPhoneNumberLong() { //tests for phone number  > 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setphoneNumber("60377089311");
		assertEquals("6037708932", contact.getphoneNumber()); // asserts that two objects are equal, the phone number length
	}

	@Test
	public void testContactCreationPhoneNumberTen() { //tests for phone number  = 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setphoneNumber("6037708931");
		assertEquals("6037708931", contact.getphoneNumber()); // asserts that two objects are equal, the phone number length
	}

	@Test
	public void testContactCreationPhoneNumberLessTen() { //tests for phone number  < 10
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setphoneNumber("60377089");
		assertEquals("6037708932", contact.getphoneNumber()); // asserts that two objects are equal, the phone number length
	}

	@Test
	public void testContactCreationAddressLong() { //tests for address number  > 30
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setaddress("1234 Berry Hill Road Rochester New Hampshire");
		assertEquals("123 Own Lane Dover NH", contact.getaddress()); // asserts that two objects are equal, the address length
	}

	@Test
	public void testContactCreationAddressThirty() { //tests for address number  = 30
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setaddress("124 Own Street Dover New Hamp");
		assertEquals("124 Own Street Dover New Hamp", contact.getaddress()); // asserts that two objects are equal, address length
																				
	}

	@Test
	public void testContactCreationAddressLessThirty() { //tests for address number  < 30
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		contact.setaddress("1 Own Stret Dover NH");
		assertEquals("1 Own Stret Dover NH", contact.getaddress()); // asserts that two objects are equal, the address length
	}

	@Test
	public void testContactCreation() { //test contact is created
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		assertNotNull(contact); // asserts that nothing is null in the contact
	}

	@Test
	public void testContactCreationID() { //tests id is created
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		assertEquals("1224", contact.getid()); // asserts that two objects are equal, the id
	}

	@Test
	public void testContactCreationFirstName() { //tests first name is created
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		assertEquals("John", contact.getfirstName()); // asserts that two objects are equal, the first name
	}

	@Test
	public void testContactCreationLastName() { //tests last name is created
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		assertEquals("Donell", contact.getlastName()); // asserts that two objects are equal, the last name

	}

	@Test
	public void testContactCreationPhoneNumber() { //tests phone number created
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		assertEquals("6037708932", contact.getphoneNumber()); // asserts that two objects are equal, the phone number

	}

	@Test
	public void testContactCreationAddress() { //tests address is created
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		assertEquals("123 Own Lane Dover NH", contact.getaddress()); // asserts that two objects are equal, the address

	}

	@Test
	public void testEquals() { // method to test that two contacts are equal
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		Contact otherContact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		// all asserts below compare the first contact with the second to assert they
		// are equal
		assertEquals(contact.getid(), otherContact.getid());
		assertEquals(contact.getfirstName(), otherContact.getfirstName());
		assertEquals(contact.getlastName(), otherContact.getlastName());
		assertEquals(contact.getaddress(), otherContact.getaddress());
		assertEquals(contact.getphoneNumber(), otherContact.getphoneNumber());
	}

	@Test
	public void testDoesNotEquals() { // method to test that two are NOT equal
		Contact contact = new Contact("1224", "John", "Donell", "6037708932", "123 Own Lane Dover NH");
		Contact otherContact = new Contact("223", "Joe", "Don", "6037708933", "12 Boe Lane Dover NH"); // other contact is different
		assertNotEquals(contact, otherContact); // asserts that two objects are not equal, contact and other contact

	}

}