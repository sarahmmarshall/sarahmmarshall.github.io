
public class Contact {
	private String id;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;

	// constructor of Contact class
	public Contact(String id, String firstName, String lastName, String phoneNumber, String address) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}

	// getter method of id
	public String getid() {
		return id;
	}

	// setter method of id
	public void setid(String ident) { // id shall not be updated
		if (ident.length() <= 10 && !ident.equals("")) { // constructors
			id = ident;
		}
	}

	public String getfirstName() { //getter of first name
		return firstName;
	}

	public void setfirstName(String first) { //setter of first name
		if (first.length() <= 10) {
			firstName = first;
		}
	}

	public String getlastName() { //getter of last name
		return lastName;
	}

	public void setlastName(String last) { //setter of last name
		if (last.length() <= 10) {
			lastName = last;
		}
	}

	public String getphoneNumber() { //getter of phone number
		return phoneNumber;
	}

	public void setphoneNumber(String PN) { //setter of phone number
		if (PN.length()== 10) {
			phoneNumber = PN; //PN is short for phone number
		}
	}

	public String getaddress() { //getter of address
		return address;
	}

	public void setaddress(String addy) { //setter of address
		if (addy.length() <= 30) {
			address = addy; //addy is short of address
		}
	}
}
